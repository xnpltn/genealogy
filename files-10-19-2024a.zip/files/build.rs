fn main() {
    slint_build::compile("ui/base.slint").unwrap();
}
